create definer = root@localhost view view_terminatedap as
select `lgu_paeis_db`.`bpls_t_bp_application`.`AP_ID`            AS `AP_ID`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_REFERENCE_NO`  AS `AP_REFERENCE_NO`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_DATE`          AS `AP_DATE`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_TYPE`          AS `AP_TYPE`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_STATUS`        AS `AP_STATUS`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_DIV_CODE_TO`   AS `AP_DIV_CODE_TO`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_DIV_CODE_FROM` AS `AP_DIV_CODE_FROM`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_DATE_ACCESSED` AS `AP_DATE_ACCESSED`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_DATE_RE_INS`   AS `AP_DATE_RE_INS`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_RE_INS_DEAD`   AS `AP_RE_INS_DEAD`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`AP_REMARKS`       AS `AP_REMARKS`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`BU_ID`            AS `BU_ID`,
       `lgu_paeis_db`.`bpls_t_bp_application`.`TB_ID`            AS `TB_ID`
from `lgu_paeis_db`.`bpls_t_bp_application`
where (`lgu_paeis_db`.`bpls_t_bp_application`.`AP_STATUS` = 'Terminated');

