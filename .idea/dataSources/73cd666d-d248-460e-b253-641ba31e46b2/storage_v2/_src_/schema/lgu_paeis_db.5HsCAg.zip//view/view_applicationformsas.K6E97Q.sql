create view view_applicationformsas as
select `ap`.`AP_REFERENCE_NO`                                                                            AS `AP_REFERENCE_NO`,
       `bus`.`BU_NAME`                                                                                   AS `BU_NAME`,
       `bus`.`BU_PRESIDENT`                                                                              AS `BU_PRESIDENT`,
       concat(`tp`.`TP_FNAME`, ' ', coalesce(`tp`.`TP_MNAME`, ' '), ' ',
              coalesce(`tp`.`TP_LNAME`, ' '))                                                            AS `TAX_PAYERNAME`,
       `bus`.`BU_LOCATION`                                                                               AS `BU_LOCATION`,
       `bus`.`BU_CONTACT`                                                                                AS `BU_CONTACT`,
       concat(`ar`.`AR_FNAME`, ' ', coalesce(`ar`.`AR_MNAME`, ' '), ' ',
              coalesce(`ar`.`AR_LNAME`, ' '))                                                            AS `AUTH_REPNAME`,
       `ar`.`AR_HOME_ADDRESS`                                                                            AS `AR_HOME_ADDRESS`,
       `bn`.`BN_NAME`                                                                                    AS `BN_NAME`,
       `bn`.`BN_CLASSIFICATION`                                                                          AS `BN_CLASSIFICATION`,
       `ot`.`OT_NAME`                                                                                    AS `OT_NAME`,
       `ot`.`OT_CODE`                                                                                    AS `OT_CODE`,
       `ap`.`AP_TYPE`                                                                                    AS `AP_TYPE`,
       `ap`.`AP_DATE`                                                                                    AS `AP_DATE`,
       `ap`.`AP_ID`                                                                                      AS `AP_ID`,
       `ap`.`AP_STATUS`                                                                                  AS `AP_STATUS`,
       `ap`.`AP_DIV_CODE_TO`                                                                             AS `AP_DIV_CODE_TO`,
       `ap`.`AP_DIV_CODE_FROM`                                                                           AS `AP_DIV_CODE_FROM`
from (((((((`lgu_paeis_db`.`bpls_t_business` `bus` join `lgu_paeis_db`.`bpls_r_business_nature` `bn` on ((`bn`.`BN_ID` = `bus`.`BN_ID`))) join `lgu_paeis_db`.`bpls_r_ownership_type` `ot` on ((`ot`.`OT_CODE` = `bus`.`OT_CODE`))) join `lgu_paeis_db`.`bpls_t_bp_application` `ap` on ((`ap`.`BU_ID` = `bus`.`BU_ID`))) join `lgu_paeis_db`.`bpls_t_taxpayer` `tp` on ((`tp`.`TP_ID` = `bus`.`TP_ID`))) join `lgu_paeis_db`.`bpls_r_bu_ar` `buxar` on ((`buxar`.`BU_ID` = `bus`.`BU_ID`))) join `lgu_paeis_db`.`bpls_t_authorize_rep` `ar` on ((`ar`.`AR_ID` = `buxar`.`AR_ID`)))
       join `lgu_paeis_db`.`bpls_r_division` `divs` on ((`divs`.`DIV_CODE` = `ap`.`AP_DIV_CODE_TO`)))
where ((`ap`.`AP_DIV_CODE_TO` = 'DIV-AS') and (`ap`.`AP_STATUS` = 'Assess') and (`ap`.`AP_STATUS` <> 'Terminated'));

