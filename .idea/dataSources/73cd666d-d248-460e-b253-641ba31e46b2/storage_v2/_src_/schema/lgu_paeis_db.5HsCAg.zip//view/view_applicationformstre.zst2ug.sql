create definer = root@localhost view view_applicationformstre as
select `bpa`.`AP_REFERENCE_NO`                                                AS `AP_REFERENCE_NO`,
       `bu`.`BU_NAME`                                                         AS `BU_NAME`,
       `nt`.`BN_NAME`                                                         AS `BN_NAME`,
       concat(`tx`.`TP_FNAME`, ' ', `tx`.`TP_MNAME`, ' ', `tx`.`TP_LNAME`)    AS `TP_NAME`,
       `tx`.`TP_HOME_ADDRESS`                                                 AS `TP_HOME_ADDRESS`,
       `t`.`TB_ID`                                                            AS `TB_ID`,
       `t`.`TB_DATE_BILLED`                                                   AS `TB_DATE_BILLED`,
       concat(`emp`.`EP_FNAME`, ' ', `emp`.`EP_MNAME`, ' ', `emp`.`EP_LNAME`) AS `EMP_NAME`
from (((((`lgu_paeis_db`.`bpls_t_bp_application` `bpa` join `lgu_paeis_db`.`bpls_t_business` `bu` on ((`bpa`.`BU_ID` = `bu`.`BU_ID`))) join `lgu_paeis_db`.`bpls_t_taxpayer` `tx` on ((`bu`.`TP_ID` = `tx`.`TP_ID`))) join `lgu_paeis_db`.`bpls_t_taxbill` `t` on ((`bpa`.`TB_ID` = `t`.`TB_ID`))) join `lgu_paeis_db`.`bpls_r_business_nature` `nt` on ((`bu`.`BN_ID` = `nt`.`BN_ID`)))
       join `lgu_paeis_db`.`bpls_t_employee_profile` `emp` on ((`t`.`ASSESSED_BY` = `emp`.`EP_ID`)))
where ((`bpa`.`AP_DIV_CODE_TO` = 'DIV-TRE') and (`bpa`.`AP_STATUS` <> 'Terminated'));

