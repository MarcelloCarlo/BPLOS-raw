create view view_bussperm as
select `permit`.`BP_NUMBER`                                                      AS `BP_NUMBER`,
       `permit`.`BP_ISSUED_DATE`                                                 AS `BP_ISSUED_DATE`,
       `taxpayer`.`TP_NATIONALITY`                                               AS `TP_NATIONALITY`,
       `business`.`BU_NAME`                                                      AS `BU_NAME`,
       concat(`btar`.`AR_FNAME`, ' ', `btar`.`AR_MNAME`, ' ', `btar`.`AR_LNAME`) AS `AR_NAME`,
       `business`.`BU_PRESIDENT`                                                 AS `BU_PRESIDENT`,
       `business`.`BU_LOCATION`                                                  AS `BU_LOCATION`,
       `permit`.`BP_VALID_YEARS`                                                 AS `BP_VALID_YEARS`,
       `nature`.`BN_NAME`                                                        AS `BN_NAME`,
       `nature`.`BN_CLASSIFICATION`                                              AS `BN_CLASSIFICATION`,
       `business`.`BU_CAPITALIZATION`                                            AS `BU_CAPITALIZATION`,
       `permit`.`BP_REMARKS`                                                     AS `BP_REMARKS`,
       `business`.`BU_EMP_NO`                                                    AS `BU_EMP_NO`,
       `taxpayer`.`TP_SSS_NO`                                                    AS `TP_SSS_NO`,
       `taxpayer`.`TP_TIN`                                                       AS `TP_TIN`,
       `business`.`BU_AREA`                                                      AS `BU_AREA`,
       `t`.`TB_ID`                                                               AS `TB_ID`,
       `t`.`TB_DATE_BILLED`                                                      AS `TB_DATE_BILLED`
from ((((((((`lgu_paeis_db`.`bpls_t_business_permit` join `lgu_paeis_db`.`bpls_t_bp_application` `a` on ((`lgu_paeis_db`.`bpls_t_business_permit`.`AP_ID` = `a`.`AP_ID`))) join `lgu_paeis_db`.`bpls_t_business` `business` on ((`a`.`BU_ID` = `business`.`BU_ID`))) join `lgu_paeis_db`.`bpls_r_business_nature` `nature` on ((`business`.`BN_ID` = `nature`.`BN_ID`))) join `lgu_paeis_db`.`bpls_r_bu_ar` `ar` on ((`business`.`BU_ID` = `ar`.`BU_ID`))) join `lgu_paeis_db`.`bpls_t_authorize_rep` `btar` on ((`ar`.`AR_ID` = `btar`.`AR_ID`))) join `lgu_paeis_db`.`bpls_t_taxpayer` `taxpayer` on ((`business`.`TP_ID` = `taxpayer`.`TP_ID`))) join `lgu_paeis_db`.`bpls_t_taxbill` `t` on ((`a`.`TB_ID` = `t`.`TB_ID`)))
       join `lgu_paeis_db`.`bpls_t_business_permit` `permit` on ((`a`.`AP_ID` = `permit`.`AP_ID`)));

