create view view_applicationformsev as
  select `ap`.`AP_REFERENCE_NO`                                                                            AS `AP_REFERENCE_NO`,
         `bus`.`BU_NAME`                                                                                   AS `BU_NAME`,
         `bus`.`BU_PRESIDENT`                                                                              AS `BU_PRESIDENT`,
         concat(`tp`.`TP_FNAME`, ' ', coalesce(`tp`.`TP_MNAME`, ' '), ' ',
                coalesce(`tp`.`TP_LNAME`, ' '))                                                            AS `TAX_PAYERNAME`,
         `bus`.`BU_LOCATION`                                                                               AS `BU_LOCATION`,
         `bus`.`BU_CONTACT`                                                                                AS `BU_CONTACT`,
         concat(`ar`.`AR_FNAME`, ' ', coalesce(`ar`.`AR_MNAME`, ' '), ' ',
                coalesce(`ar`.`AR_LNAME`, ' '))                                                            AS `AUTH_REPNAME`,
         `ar`.`AR_HOME_ADDRESS`                                                                            AS `AR_HOME_ADDRESS`,
         `bn`.`BN_NAME`                                                                                    AS `BN_NAME`,
         `bn`.`BN_CLASSIFICATION`                                                                          AS `BN_CLASSIFICATION`,
         `ot`.`OT_NAME`                                                                                    AS `OT_NAME`,
         `ot`.`OT_CODE`                                                                                    AS `OT_CODE`,
         `ap`.`AP_TYPE`                                                                                    AS `AP_TYPE`,
         `ap`.`AP_DATE`                                                                                    AS `AP_DATE`,
         `atc`.`AT_UNIFIED_FILE_NAME`                                                                      AS `AT_UNIFIED_FILE_NAME`,
         `ap`.`AP_ID`                                                                                      AS `AP_ID`,
         `ap`.`AP_STATUS`                                                                                  AS `AP_STATUS`,
         `ap`.`AP_DIV_CODE_TO`                                                                             AS `AP_DIV_CODE_TO`,
         `ap`.`AP_DIV_CODE_FROM`                                                                           AS `AP_DIV_CODE_FROM`,
         `atc`.`AT_ID`                                                                                     AS `AT_ID`,
         `atc`.`AT_BRGY_CLEARANCE`                                                                         AS `AT_BRGY_CLEARANCE`,
         `atc`.`AT_DTI_REGISTRATION`                                                                       AS `AT_DTI_REGISTRATION`,
         `atc`.`AT_SEC_REGISTRATION`                                                                       AS `AT_SEC_REGISTRATION`,
         `atc`.`AT_TITLE_TO_PROPERTY`                                                                      AS `AT_TITLE_TO_PROPERTY`,
         `atc`.`AT_TAX_DECLARATION`                                                                        AS `AT_TAX_DECLARATION`,
         `atc`.`AT_CONTRACT_OF_LEASE`                                                                      AS `AT_CONTRACT_OF_LEASE`,
         `atc`.`AT_LESSORS_BP`                                                                             AS `AT_LESSORS_BP`,
         `atc`.`AT_AUTHORIZATION`                                                                          AS `AT_AUTHORIZATION`,
         `atc`.`AT_LOCATIONAL_CLR`                                                                         AS `AT_LOCATIONAL_CLR`,
         `atc`.`AT_SANITARY_HEALTH_CERT`                                                                   AS `AT_SANITARY_HEALTH_CERT`,
         `atc`.`AT_BUILDING_PERMIT`                                                                        AS `AT_BUILDING_PERMIT`,
         `atc`.`AT_POLLUTION_CLR`                                                                          AS `AT_POLLUTION_CLR`,
         `atc`.`AT_MECHANICAL_PERMIT`                                                                      AS `AT_MECHANICAL_PERMIT`,
         `atc`.`AT_ELECTRICAL_INSP`                                                                        AS `AT_ELECTRICAL_INSP`,
         `atc`.`AT_POLICE_CLEARANCE`                                                                       AS `AT_POLICE_CLEARANCE`,
         `atc`.`AT_CTAO_CLEARANCE_CERT`                                                                    AS `AT_CTAO_CLEARANCE_CERT`,
         `atc`.`AT_FSIC`                                                                                   AS `AT_FSIC`,
         `atc`.`AT_PREV_BP`                                                                                AS `AT_PREV_BP`,
         `atc`.`AT_TAX_BILL`                                                                               AS `AT_TAX_BILL`,
         `atc`.`AT_OFFICIAL_RECEIPT`                                                                       AS `AT_OFFICIAL_RECEIPT`,
         `atc`.`AT_PCAB_LICENSE`                                                                           AS `AT_PCAB_LICENSE`,
         `atc`.`AT_MISC_DOCUMENTS`                                                                         AS `AT_MISC_DOCUMENTS`,
         `atc`.`AP_Remarks`                                                                                AS `AP_Remarks`
  from ((((((((`lgu_paeis_db`.`lgu_t_business` `bus` join `lgu_paeis_db`.`lgu_r_business_nature` `bn` on ((`bn`.`BN_ID`
                                                                                                           =
                                                                                                           `bus`.`BN_ID`))) join `lgu_paeis_db`.`lgu_r_ownership_type` `ot` on ((
    `ot`.`OT_CODE` = `bus`.`OT_CODE`))) join `lgu_paeis_db`.`lgu_t_bp_application` `ap` on ((`ap`.`BU_ID` =
                                                                                             `bus`.`BU_ID`))) join `lgu_paeis_db`.`lgu_t_taxpayer` `tp` on ((
    `tp`.`TP_ID` = `bus`.`TP_ID`))) join `lgu_paeis_db`.`lgu_r_bu_ar` `buxar` on ((`buxar`.`BU_ID` =
                                                                                   `bus`.`BU_ID`))) join `lgu_paeis_db`.`lgu_t_authorize_rep` `ar` on ((
    `ar`.`AR_ID` = `buxar`.`AR_ID`))) join `lgu_paeis_db`.`lgu_t_attachments` `atc` on ((`atc`.`AP_ID` =
                                                                                         `ap`.`AP_ID`))) join `lgu_paeis_db`.`lgu_r_division` `divs` on ((
    `divs`.`DIV_CODE` = `ap`.`AP_DIV_CODE_TO`)))
  where ((`ap`.`AP_DIV_CODE_TO` = 'DIV-EV') and ((`ap`.`AP_STATUS` = 'Pending') or (`ap`.`AP_STATUS` = 'Assess')));

