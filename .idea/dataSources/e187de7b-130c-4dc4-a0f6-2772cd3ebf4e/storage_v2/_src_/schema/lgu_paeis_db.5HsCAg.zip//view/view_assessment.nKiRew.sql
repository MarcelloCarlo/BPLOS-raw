create view view_assessment as
  select `bus`.`BU_ID`              AS `BUID`,
         `_as`.`AS_OR_NO`           AS `AS_OR_NO`,
         `_as`.`AS_PERIOD_COVERED`  AS `AS_PERIOD_COVERED`,
         `_as`.`AS_DUE_DATE`        AS `AS_DUE_DATE`,
         `_as`.`AS_PAYMENT_DATE`    AS `AS_PAYMENT_DATE`,
         `_as`.`AS_AP_REFERENCE_NO` AS `AP_REFERENCE_NO`,
         `bus`.`BU_NAME`            AS `BU_NAME`,
         `bus`.`BU_LOCATION`        AS `BU_LOCATION`,
         `bus`.`BU_CONTACT`         AS `BU_CONTACT`,
         `f`.`FEES_NAME`            AS `FEES_NAME`,
         `f`.`AMOUNT`               AS `AMOUNT`
  from ((((`lgu_paeis_db`.`lgu_t_assessment` `_as` join `lgu_paeis_db`.`lgu_t_bp_application` `ap` on ((
    `ap`.`AP_REFERENCE_NO` = `_as`.`AS_AP_REFERENCE_NO`))) join `lgu_paeis_db`.`lgu_r_fee_set` `fs` on ((`fs`.`FS_CODE`
                                                                                                         =
                                                                                                         `_as`.`AS_FEE_SET`))) join `lgu_paeis_db`.`lgu_r_fees` `f` on ((
    `f`.`FEES_CODE` = `fs`.`FS_PRM_FEE`))) join `lgu_paeis_db`.`lgu_t_business` `bus` on ((`bus`.`BU_ID` =
                                                                                           `ap`.`BU_ID`)));

